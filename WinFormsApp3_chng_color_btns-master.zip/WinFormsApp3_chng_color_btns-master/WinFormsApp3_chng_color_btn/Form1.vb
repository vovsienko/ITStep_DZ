﻿Public Class Form1
    Private Sub btnRed_Click(sender As Object, e As EventArgs) Handles btnRed.Click
        lblDisplay.BackColor = Color.Red
    End Sub

    Private Sub btnGreen_Click(sender As Object, e As EventArgs) Handles btnGreen.Click
        lblDisplay.BackColor = Color.Green
    End Sub
End Class